"""
Deploy করার পর এই script একবার run করুন।
Vercel URL দিয়ে Telegram webhook set করবে।
"""
import asyncio
from telegram import Bot

BOT_TOKEN = "8916888298:AAEIuLU0f4n_DuVXNhKj5bs22D5LtS0eWHA"
VERCEL_URL = "https://YOUR-APP.vercel.app"  # আপনার Vercel URL দিন

async def set_webhook():
    bot = Bot(token=BOT_TOKEN)
    webhook_url = f"{VERCEL_URL}/api/webhook"
    result = await bot.set_webhook(url=webhook_url)
    print(f"Webhook set: {result}")
    info = await bot.get_webhook_info()
    print(f"Webhook URL: {info.url}")

asyncio.run(set_webhook())
